import React from 'react';
import ReactDOM from 'react-dom';
import { Button, Modal, FormGroup, Grid, Row, InputGroup, ValidatedInput ,Col,ControlLabel,
	    FormControl } from 'react-bootstrap';
import strings from '../Constants';
import { validateGroupName } from '../../../Utils/ValidateInput';
import { ERRORCODE } from '../Constants';
import { AddGroupAction } from '../Action/AddGroupAction';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

class AddGroupContainer extends React.Component{

	constructor(props) {
		super(props);

 		this.state = {
 			showModal : false,
 			isValidName : null,
 			addGroupResponseStatus : null
  		};

		this.open = this.open.bind(this);
 		this.close = this.close.bind(this);
 		this.enterPress_AddGroup = this.enterPress_AddGroup.bind(this);
 		this.handleClick_save = this.handleClick_save.bind(this);
 		this.setValidation = this.setValidation.bind(this);

	}
	componentDidUpdate()
	{
			if( this.state.addGroupResponseStatus == ERRORCODE.SUCCESS )
			{
				document.getElementById("success_msg").innerHTML = strings.SuccessMessage;
				document.getElementById("error_msg").innerHTML = '';
			}
			else if( this.state.addGroupResponseStatus == ERRORCODE.DUPLICATE_USER_GROUP )
			{
				ReactDOM.findDOMNode(this.refs.refName).value = '';
				document.getElementById("error_msg").innerHTML = strings.DuplicateGroupName;
			}
			else if( this.state.addGroupResponseStatus == ERRORCODE.ADD_GROUP_FAILED )
			{
				ReactDOM.findDOMNode(this.refs.refName).value = '';
				document.getElementById("error_msg").innerHTML = strings.AddGroupFailed;
			}
			else if( this.state.addGroupResponseStatus == ERRORCODE.ERROR_CREATING_USERGROUP )
			{
				ReactDOM.findDOMNode(this.refs.refName).value = '';
				document.getElementById("error_msg").innerHTML = strings.ErrorCreatingGroup;
			}

	}
	setValidation( errorCode )
 	{
 		if( errorCode == ERRORCODE.SUCCESS )
 		{
 			this.setState({ isValidName: null , addGroupResponseStatus : ERRORCODE.SUCCESS });
 		}
 		if ( errorCode ==  ERRORCODE.DUPLICATE_USER_GROUP )
 		{
 			this.setState({ isValidName: "error" , addGroupResponseStatus : ERRORCODE.DUPLICATE_USER_GROUP });

		}
		if( errorCode ==  ERRORCODE.ADD_GROUP_FAILED )
		{
			this.setState({ isValidName: "error" , addGroupResponseStatus : ERRORCODE.ADD_GROUP_FAILED });
		}
		if( errorCode == ERRORCODE.ERROR_CREATING_USERGROUP )
       	{
       		this.setState({ isValidName: "error" , addGroupResponseStatus : ERRORCODE.ERROR_CREATING_USERGROUP });
       	}
 	}
	handleClick_save()
	{
		this.setState({ isValidName : null, addGroupResponseStatus : null });
		var groupName = (ReactDOM.findDOMNode(this.refs.refName).value);
		var clientId = 30;

		if( groupName == '' )
		{
			this.setState({ isValidName: "error" });
			document.getElementById("error_msg").innerHTML = strings.EmptyFieldMsg;
			document.getElementById("success_msg").innerHTML = '';
		}
		else
		{
			var isValidName = validateGroupName( groupName );
			if( isValidName == true )
			{
				this.props.AddGroupAction( clientId, groupName, this.setValidation );
			}
			else
			{
				this.setState({ isValidName: "error" });
				ReactDOM.findDOMNode(this.refs.refName).value = '';
				document.getElementById( "error_msg" ).innerHTML = strings.InvalidGroupName;
				document.getElementById("success_msg").innerHTML = '';
			}
		}
	}
	enterPress_AddGroup()
	{
		var keypress = event.target.value;

		if(event.charCode == 13)
		{
	        this.handleClick_save();
	    }
	}
	close()
   	{
    	this.setState({ showModal: false });
  	}

	open()
	{
		this.setState({ isValidName : null, addGroupResponseStatus : null });
		this.setState({ showModal: true });
	}

	render()
	{
			return (
			<Col xs={12}>
				<Button type = "submit" onClick={ this.open }>{ strings.HeaderAddGroup }</Button>
				<Modal className="modal_content_AddGroup" show={this.state.showModal}>
	    			<Modal.Header  className="model-header" >
	    				<Col xs={12}>
	        				<Col xs={6}>
	          					<h className="model_header_AddGroup">{strings.HeaderAddGroup}</h>
	          				</Col>
	          				<Col xs={6}>

		          			</Col>
	      				</Col>
	  				</Modal.Header>

	          			<Modal.Body className="removePadding">


	     			<Col xs={12} className="noPadding" id="form">
	     				<ControlLabel className="modal-body-content_AddGroup Required">{ strings.AddGroupName }</ControlLabel>
	     				<ControlLabel className="Required">*</ControlLabel>
	     					<FormGroup controlId="formValidationError" validationState = { this.state.isValidName }>
	                        <FormControl className="forgotpwd-textbox_AddGroup" ref = "refName" type="text" onKeyPress = { this.enterPress_AddGroup }/>
	        			</FormGroup>
	        			<div id="error_msg" className="error_addGroup"></div>
	        			<div id="success_msg" className="addGroupSuccessMsg"></div>
	                </Col>
									</Modal.Body>

	       			<div className="row noPadding ">
	      				<Modal.Footer id="footer_modal">
		    					<Button type="submit" className="button_Save_AddGroup" onClick = { this.handleClick_save }>
		      					<p className="font_button">{ strings.AddGroupSaveButton } </p>
		      					</Button>
	      					<Button type="submit" className="button_Cancel_AddGroup" onClick = { this.close } >
	      						<p className="font_button">{ strings.AddGroupCancelButton }</p>
	      					</Button>
  	          	</Modal.Footer>
	      			</div>
 			</Modal>
 		</Col>
 		);
	}
}
function mapStateToProps(state){
	return{
		auth_login:state.auth_login
	};
}
function matchDispatchToProps(dispatch){
 	return bindActionCreators({ AddGroupAction : AddGroupAction },dispatch)
}
export default connect(mapStateToProps, matchDispatchToProps)(AddGroupContainer);
