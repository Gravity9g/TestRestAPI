import React, { Component } from 'react';
import { Col } from 'react-bootstrap';

import AddGroupContainer from '../Container/AddGroupContainer';


class AddGroup extends Component{
	render(){
		return(
			< AddGroupContainer />
		);
	}
}

export default AddGroupContainer;
