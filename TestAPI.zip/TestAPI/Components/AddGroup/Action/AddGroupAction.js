import { ADD_GROUP } from '../Constants';
import { Configurations } from '../../../Utils/config';
import axios from 'axios';
import { ERRORCODE, ADDGROUP_ERROR } from '../Constants';

//////////////////////////////////////////////////////////////////////////////////////////////////////
//Function Name:    AddGroupAction                                                                  //
//Parameters   :    clientId, groupName, setValidation(call back function)                          //
//Description  :    Add group Api called to add the group name for the specific client_id.          //
//Auther       :    Madhuri Dethe                                                                   //
//////////////////////////////////////////////////////////////////////////////////////////////////////

export function AddGroupAction( clientId, groupName, setValidation )
{
    console.log("inside addgroup api action");
    return function(dispatch)
    {
        return axios.post( Configurations.AddGroupApi,
            {
              "cid": clientId,
              "nam": groupName,
            },{ withCredentials: true } )
        .then( response => {
        
            console.log( response);
            if ( response.status == 200 )
            {
                var errorCode = getErrorCode(response.data.st);

                if ( errorCode == ERRORCODE.SUCCESS )
                    {
                        setValidation(ERRORCODE.SUCCESS);  
                    }
                    else if( errorCode == ERRORCODE.ADD_GROUP_FAILED )
                    {
                        setValidation( ERRORCODE.ADD_GROUP_FAILED );
                    }
                    else if( errorCode == ERRORCODE.DUPLICATE_USER_GROUP )
                    {
                        setValidation( ERRORCODE.DUPLICATE_USER_GROUP );
                    }
                    else if( errorCode == ERRORCODE.ERROR_CREATING_USERGROUP )
                    {
                         setValidation( ERRORCODE.ERROR_CREATING_USERGROUP );
                    }
            }

        })
        .catch(( error ) => {
            console.log( error );
            setValidation( ERRORCODE.ADD_GROUP_FAILED );
          })
    }
}


///////////////////////////////////////////////////////////////////////////////////////////////////////
//Function Name:    getErrorCode                                                                     //
//Parameters   :    statusCode                                                                       //
//Description  :    Error code mapping to the constants.                                             //
//Auther       :    Madhuri Dethe                                                                    //
///////////////////////////////////////////////////////////////////////////////////////////////////////

function getErrorCode( statusCode )
{
    var errorCode = ERRORCODE.SUCCESS;

    switch(statusCode)
    {
        case 0 :
        errorCode = ERRORCODE.SUCCESS;
        break;
        
        case 201 :
        errorCode = ERRORCODE.ADD_GROUP_FAILED;
        break;

        case 204 :
        errorCode = ERRORCODE.DUPLICATE_USER_GROUP;
        break;

        case 206:
        errorCode = ERRORCODE.ERROR_CREATING_USERGROUP;
       
        case 401 :
        errorCode = ERRORCODE.ADD_GROUP_FAILED;
        break;
    }

    return errorCode;
}