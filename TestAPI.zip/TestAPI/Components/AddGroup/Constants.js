import LocalizedStrings from 'react-localization';
import { Configurations } from '../../Utils/config.js';

export const ADD_GROUP = 'add_group';

export const ERRORCODE = {
  SUCCESS : 0,
  DUPLICATE_USER_GROUP : 1,
  ADD_GROUP_FAILED : 2,
  ERROR_CREATING_USERGROUP : 3
  
}; 

let strings = new LocalizedStrings({
    EN:
    {
      HeaderAddGroup : "Add Group",
      AddGroupCancelButton : "Cancel",
      AddGroupSaveButton : "Save",
      AddGroupName : "Name",
      EmptyFieldMsg : "Please fill out the field",
      InvalidGroupName : "Invalid Group Name",
      DuplicateGroupName : "Duplicate group name",
      SuccessMessage : "Group added successfully",
      AddGroupFailed : "Add group failed",
      ErrorCreatingGroup : "Error creating group"
      
    },
    MR:
    {
      
    },
    ES:
    {
      
    }
});

strings.setLanguage(Configurations.lang);

export default strings;
