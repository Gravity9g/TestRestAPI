import { APP_START_ACTION } from '../../../Components/Login/Constants';

export function appStartAction(subdomain){
    return({
            type: APP_START_ACTION,
            subdomain: subdomain
        }
    );
}
