import React, { Component } from 'react';
import axios from 'axios';
import ReactDOM from 'react-dom';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

//import Input from '../Container/Input';
let __file,host,api;
class Input extends Component{
    constructor(props){
        super(props);

          this.state={
            file:'88',
          }

        this.change=this.change.bind(this);


    }

  change(e){
  __file=e.target.files[0];
    this.setState({
      file:'asd'
    })
      console.log(e.target.files[0])
}



// This Function is called when you chose to test API with file
testFileAPI(){
  if(document.getElementById("host").value=='')
    alert("Host Is Not Choosen Smriti or may be wrong one !!\n\n Come On do it agin now !! \n\n||AND PLEASE DON'T PREVENT ME FROM WARRNING YOU\n\n");
  if(document.getElementById("api").value=='')
      alert("API Is Not Choosen Smriti or may be wrong one !!\n\n Come On do it agin now !! \n\n||AND PLEASE DON'T PREVENT ME FROM WARRNING YOU\n\n");

      host=document.getElementById("host").value;
      api=document.getElementById("api").value;


  // This Will Show You On console which file you chosed to pass in request
  //Open console on browser by pressing f12 and chose tab consol

  console.log(__file);
  console.log(host);
  console.log(api);


//  Prepare request here before clicking TestAPI button else API test fails

/*//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@**

 REMEMBER : In following request  __file is file object which you choosed on html do not change it !!!

//@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@*/

                            //// here is dummy request

                          const request = new FormData();
                          request.append('fileUpload', __file);
                          request.append('nam', "suhas more");
                          request.append('id', 12);
                          request.append('catid', 0);
                          request.append('desc', "SUHAS IS A VERY SMART BOY ;-)");

                          // actual API call goes here
                          return axios.post(

                                            host+api,
                                            request,
                                            { withCredentials: true,headers: { 'Content-Type': 'multipart/form-data'}}

                          ).then(response => {
                           console.log( response );
                           if ( response.status == 200 ) {
                             alert("response:200");
                               console.log("response from server is 200 success");
                           }else {
                             alert("something went wrong");
                                 console.log("error");
                               }


                           }).catch(err => {
                             alert(err);
                           console.error('Error: ', err);
                          })

}

testAPI(){
  if(document.getElementById("host").value=='')
    alert("Host Is Not Choosen Smriti or may be wrong one !!\n\n Come On do it agin now !! \n\n||AND PLEASE DON'T PREVENT ME FROM WARRNING YOU\n\n");
  if(document.getElementById("api").value=='')
      alert("API Is Not Choosen Smriti or may be wrong one !!\n\n Come On do it agin now !! \n\n||AND PLEASE DON'T PREVENT ME FROM WARRNING YOU\n\n");

      host=document.getElementById("host").value;
      api=document.getElementById("api").value;


                      var  request={
                                      "nam":"suhas more",
                                      "id":25,
                                      "desc":"this is plane request without file param",
                                      "rtyp":"PHISHLABS",


                                    }

                                    // actual API call goes here
                                    return axios.post(

                                                      host+api,
                                                      request,
                                                      { withCredentials: true}

                                    ).then(response => {
                                     console.log( response );
                                     if ( response.status == 200 ) {
                                       alert("response:200");
                                         console.log("response from server is 200 success");
                                     }else {
                                       alert("something went wrong");
                                           console.log("error");
                                         }


                                     }).catch(err => {
                                       alert(err);
                                     console.error('Error: ', err);
                                    })


}

	render(){
		return(
				  <div className="conatainer-__fileuied">
            <div className="row author">
            <h3 className="col-lg-12"> TEST REST API WITH REACT <small className="name"> :By Suhas More</small> </h3>

            <cm className=" pull-right cmpny">SpringCT</cm>
            </div>

              <div className="row mandetory">
                <div className="col-lg-12">
                  <div className="col-lg-8">
                    <lable className="lable">Host Name : </lable><input type="text" className=" Input" id="host" width="20" placeholder="http:172.124.0.24"/>
                    <br/><br/>
                    <lable className="lable">API Name: </lable><input type="text" className=" Input" id="api" placeholder="PortalServer/auth/login"/>
                  </div>
              </div>

              </div>



            <div className="row">

              <div className="col-lg-6">
                <heading className="heading">With File Param API </heading>
                <div className="loginBackground">
                  <input type="file" className=" btn padding-4per inputDefault" id="fileUpload" onChange={this.change}/>
                    <div className="padding-4per">
                      <button className="btn btn-danger " onClick={this.testFileAPI}>Test With File</button>
                    </div>
                    <div className="padding-2per error_text">
                      <p>Note : You Have to change API name and all params According To Which API you are going to test</p>
                      <p> in testFileAPI() function which is  in file Input.js @ Line:33</p>

                    </div>

                </div>
              </div>

              <div className="col-lg-6">
                <heading className="heading">Without File Param API </heading>
                <div className="loginBackground">
                    <div className="padding-4per">
                      <button className="btn btn-success " onClick={this.testAPI}>Test With File</button>
                    </div>

                    <div className="padding-2per error_text">
                      <p>Note : You Have to change API name and all params According To Which API you are going to test</p>
                      <p> in testAPI() function which is in file Input.js @ Line:93</p>
                      <p><br/><br/><br/></p>

                    </div>


                </div>
              </div>



            </div>
            <div className="row author">
            <h3 className="col-lg-12"> TEST REST API WITH REACT <small className="name"> <a href="http://about.me/suhas-more"  className="link"> :By Suhas More</a></small> </h3>

            <cm className=" pull-right cmpny">SpringCT</cm>

            </div>
         </div>






    );
	}

}


export default Input;
