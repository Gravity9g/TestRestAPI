import React, { Component } from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';

import Input from '../Container/Input';

class App extends Component{
    constructor(props){
        super(props);
    }

	render(){
		return(
				  <div className="conatainer">
              <Input/>
         </div>
		);
	}

}


export default App;
