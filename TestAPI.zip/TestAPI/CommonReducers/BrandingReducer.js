import { BRANDING_INFO_ACTION, LOGOUT_ACTION, APP_START_ACTION } from '../Components/Login/Constants';

const INTIAL_STATE = {
    logo: null,
    backgroundColor: null,
    highlight: null,
    subdomain: null
};

export default function (state = INTIAL_STATE, action) {
    switch(action.type) {

        case BRANDING_INFO_ACTION:
            return Object.assign({}, state, {
                logo: action.logo,
                backgroundColor: action.backgroundColor,
                highlight: action.highlight,
            });
            break;

        case LOGOUT_ACTION:
            return Object.assign({}, state, {
                logo: null,
                backgroundColor: null,
                highlight: null,
                subdomain: null
            });
            break;

        case APP_START_ACTION:
            return Object.assign({}, state, {
                subdomain: action.subdomain
            });
            break;

        default:
            return state;
    }
}
