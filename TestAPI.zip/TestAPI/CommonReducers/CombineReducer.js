import {combineReducers} from 'redux';
import AuthSetPasswordReducer from '../Components/SetPassword/Reducer/SetPasswordReducer';
import AuthLoginReducer from '../Components/Login/Reducer/LoginReducer';
import ClientListReducer from '../Components/ClientManagement/Reducer/ClientReducer';
import SearchReducer from '../Components/Search/Reducer/SearchReducer';
import ImportUserReducer from '../Components/ImportUsers/Reducer/ImportUsersReducer';
import ResellerReducer from '../Components/ResellerManagement/Reducer/ResellerReducer';
import BrandingReducer from './BrandingReducer';
import SidebarReducer from '../Components/SideBar/Reducer/SidebarReducer';

const allReducers=combineReducers({
  auth_login : AuthLoginReducer,
  Set_Password : AuthSetPasswordReducer,
  client_info : ClientListReducer,
  search_values : SearchReducer,
  ImportUser : ImportUserReducer,
  reseller_info : ResellerReducer,
  brandingInfo : BrandingReducer,
  sidebarInfo: SidebarReducer,
});

export default allReducers;
