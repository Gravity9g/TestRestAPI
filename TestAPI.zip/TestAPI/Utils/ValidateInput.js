export function validateNameInput(Input){
	var regex  = /^[a-zA-Z]{1,50}$/;
    var valid = regex.test(Input);
    return valid;
}
export function validateNameInputIncludingSpace(Input){
    var regex  = /^[a-zA-Z0-9+\s\-+\.+\,+\?+\@+\&+\!+\#+\'+\*+\_+\;+\(+\)+\+]{1,50}$/;
    var valid = regex.test(Input);
    return valid;
}
export function validateEmailInput(Input) {
	var regex  = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    var valid = regex.test(Input);
    return valid;
}
export function validatePassword(Input) {
		var regex = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[#$&*@!]).{8,32}$/;;
		var valid = regex.test(Input);
        return valid;
}
export function validatePhoneInput(Input) {
	var regex  = /^[(]{0,1}[0-9]{3}[)]{0,1}[-\s\.]{0,1}[0-9]{3}[-\s\.]{0,1}[0-9]{4}$/;
    var valid = regex.test(Input);
    return valid;
}
export function validateExtensionInput(Input){
	var regex  = /^[0-9]{0,4}$/;
    var valid = regex.test(Input);
    return valid;
}
export function validateMaxLen50(Input) {
	var regex  = /^[^-\s][a-zA-Z0-9_\s-]{1,50}$/;
    var valid = regex.test(Input);
    return valid;
}
export function validateMaxLen150(Input){
	var regex  = /^.{1,150}$/;
    var valid = regex.test(Input);
    return valid;
}

// export function validateSubDomainName(Input){
// 	var regex  = /^[a-z0-9]+([\-\.]{1}[a-z0-9]+)$/
//     var valid = regex.test(Input);
//     return valid;
// }
export function validateDomainName(Input){
	//var regex  = /^[a-z0-9]+([\-\.]{1}[a-z0-9]+)*(\.com|\.net|\.biz|\.org|\.info)$/
    var regex = /^[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,6}$/
    var valid = regex.test(Input);
    return valid;
}
export function validateEmployeeNumberInput(Input){
    var regex = /^[\S\s]{1,50}$/;
    var valid = regex.test(Input);
    return valid;
}
export function validateDepartmentInput(Input){
    var regex = /^[\S\s]{1,50}$/;
    var valid = regex.test(Input);
    return valid;
}
export function validateLocationInput(Input){
    var regex = /^[\S\s]{1,50}$/;
    var valid = regex.test(Input);
    return valid;
}
export function validateJobTitleInput(Input){
    var regex = /^[\S\s]{1,50}$/;
    var valid = regex.test(Input);
    return valid;
}
export function validateCostCenterInput(Input){
    var regex = /^[\S\s]{1,100}$/;
    var valid = regex.test(Input);
    return valid;
}
export function validateBusinessUnitInput(Input){
    var regex = /^[\S\s]{1,100}$/;
    var valid = regex.test(Input);
    return valid;
}
export function validateGroupName(Input){
    var regex = /^.{1,15}$/;
    var valid = regex.test(Input);
    return valid;
}
export function validateNumberOfLicense(Input){
	var regex  = /^[0-9]{1,10}$/;
    var valid = regex.test(Input);
    return valid;
}
export function validateZipCode(Input){
	var regex  = /^[a-zA-Z0-9-]{4,10}$/;
    var valid = regex.test(Input);
    return valid;
}
